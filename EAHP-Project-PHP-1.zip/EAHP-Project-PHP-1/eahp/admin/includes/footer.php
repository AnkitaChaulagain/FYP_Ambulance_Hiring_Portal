<div class="footer">
			<div class="wthree-copyright">
			  <p> Emergency Ambulance Portal System All rights reserved.</p>
			</div>
		  </div>